document.addEventListener('DOMContentLoaded', function() {
    const selectableElements = document.querySelectorAll('.selectable');
    
        selectableElements.forEach(element => {
        element.addEventListener('click', function() {
            selectableElements.forEach(el => el.classList.remove('selected'));
            this.classList.add('selected');
        });
    });
});
